package com.example.datafirebase

import android.content.ContentValues.TAG
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.core.content.edit
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.io.Serializable

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Obtén el SharedPreferences
        val sharedPreferences = getSharedPreferences("MySharedPreferences", Context.MODE_PRIVATE)

        // Verifica si ya hay una sesión iniciada
        if (sharedPreferences.contains("username") && sharedPreferences.contains("password")) {
            // Abre la actividad MainActivity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

            // Cierra la actividad LoginActivity
            finish()
        } else {
            // Muestra la actividad LoginActivity
            setContentView(R.layout.activity_login)

            // Obtener los elementos del layout
            val usernameEditText = findViewById<EditText>(R.id.usernameEditText)
            val passwordEditText = findViewById<EditText>(R.id.passwordEditText)
            val loginButton = findViewById<Button>(R.id.loginButton)

            // Agregar un listener para el botón de inicio de sesión
            loginButton.setOnClickListener {
                // Obtener los valores de los campos de texto
                val username = usernameEditText.text.toString()
                val password = passwordEditText.text.toString()

                //Conexion de firebase para traer los perfiles
                val db = FirebaseFirestore.getInstance()
                val perfilRef = db.collection("Perfil")


                perfilRef.get().addOnSuccessListener { querySnapshot ->
                    val datos = mutableMapOf<String, Map<String, Any>>()
                    for (document in querySnapshot) {
                        datos[document.id] = document.data
                    }
                    // Aquí ya tienes todos los datos en el mapa "datos"
                    val perfiles = datos.map { it.value }.toList()

                    //Buscar en el mapa de datos username y contraseña que es nombreUnico y contraseña
                    val perfil = perfiles.filter { it["nombreUnico"] == username }.firstOrNull()
                    if (perfil != null && perfil["contraseña"] == password) {
                        // Usuario y contraseña son correctos
                        // Guardar la información de inicio de sesión en SharedPreferences
                        sharedPreferences.edit {
                            putString("username", username)
                            putString("password", password)
                        }

                        // Abrir la actividad MainActivity
                        val intent = Intent(this, MainActivity::class.java)

                        val bundle = Bundle()
                        bundle.putSerializable("perfil", perfil as Serializable)
                        intent.putExtras(bundle)
                        startActivity(intent)

                        // Cierra la actividad LoginActivity
                        finish()
                    } else {
                        // Usuario y/o contraseña son incorrectos
                        Log.e(TAG, "nombre y contraseña incorrectos")
                    }

                }.addOnFailureListener { exception ->
                    Log.e(TAG, "Error al obtener datos: ", exception)
                }

            }
        }
    }
}
