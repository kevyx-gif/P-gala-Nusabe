package com.example.datafirebase

import android.content.ContentValues.TAG
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Recuperar el perfil del intent
        // Obtén el Bundle del Intent
        val bundle = intent.extras

        // Verifica que el Bundle no sea nulo y que contenga la clave "perfil"
        if (bundle != null && bundle.containsKey("perfil")) {
            // Obtiene el HashMap del Bundle y lo convierte de nuevo a un HashMap
            val perfil = bundle.getSerializable("perfil") as? HashMap<String, Any>

            // Verifica que el perfil no sea nulo y realiza las operaciones necesarias
            if (perfil != null) {

                //Treaer los ids de productos que tenga el perfil
                val IDS = mutableListOf<String>()
                for (producto in perfil["Productos"] as Map<String, Any>) {
                    if (producto.key == "id") {
                        IDS.add(producto.value.toString())
                    }
                }

                //Buscar estos productos y guardarlos en una map
                val db = FirebaseFirestore.getInstance()
                val productosRef = db.collection("Producto")
                val productosMap = mutableMapOf<String, Map<String, Any>>()
                for (id in IDS) {
                    productosRef.whereEqualTo("id", id).get().addOnSuccessListener { querySnapshot ->
                        for (document in querySnapshot) {
                            productosMap[document.data["nombre"].toString()] = document.data
                        }

                        //productosMap ya tiene el mapa de productos, ya solo es enviarlo a los demas activity o fragments

                    }.addOnFailureListener { exception ->
                        Log.e(TAG, "Error al obtener datos: ", exception)
                    }
                }


            }else {
                Log.e(TAG, "Perfil es nulo")
            }
        }
    }
}