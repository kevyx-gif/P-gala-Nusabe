package com.example.pruebasfirebase

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [mostrarDatos.newInstance] factory method to
 * create an instance of this fragment.
 */
class mostrarDatos : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_mostrar_datos, container, false)
        val rv = view?.findViewById<RecyclerView>(R.id.recyclerView)
        // Find the button by its ID
        val button = view?.findViewById<Button>(R.id.botonTraer)

        // Set the OnClickListener to handle the button click
        button?.setOnClickListener {

            // Get a reference to the Firestore database
            // Inflate the layout for this fragment
            val db = Firebase.firestore
            val collectionRef = db.collection("Producto")
            val productos = mutableListOf<Producto>()

            collectionRef.get()
                .addOnSuccessListener { result ->
                    for (document in result) {
                        // Obtener los valores del HashMap y mapearlos al objeto Producto
                        val nombre = document["nombre"] as String
                        val precio = (document["precio"] as? String)?.toDoubleOrNull() ?: 0.0
                        val consumidoresList = mutableListOf<Consumidor>()
                        val consumidoresMap = document["consumidores"] as Map<String, Map<String, Any>>
                        for ((_, value) in consumidoresMap) {
                            val nombreAmigo = value["nombre"] as String
                            val responsable = value["responsable"] as Boolean
                            consumidoresList.add(Consumidor(nombreAmigo, responsable))
                        }
                        productos.add(Producto(nombre, precio, consumidoresList))
                        Log.d("TAG", productos.toString())
                        rv?.adapter = Adaptador(productos)
                        rv?.layoutManager = LinearLayoutManager(requireContext())
                        // Add your code here to handle the button click
                        Toast.makeText(requireContext(), "Datos Recibidos Correctamente", Toast.LENGTH_LONG).show()
                    }
                }
                .addOnFailureListener { exception ->
                    Log.d("TAG", "Error getting documents: ", exception)
                }
        }

        return view
    }






    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment mostrarDatos.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            mostrarDatos().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}