package com.example.pruebasfirebase

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AdaptadorAmigos(var Consumidor: List<Consumidor>) : RecyclerView.Adapter<AdaptadorAmigos.ViewHolder>() {
    class ViewHolder(v: View) : RecyclerView.ViewHolder(v) {
        var nombre: TextView
        var abono: TextView

        init {
            nombre = v.findViewById(R.id.textViewNombreAmigo)
            abono = v.findViewById(R.id.textViewAbono)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.fila_amigos, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val c = Consumidor[position]
        holder.nombre.text = c.nombre
        holder.abono.text = c.abono.toString()
    }

    override fun getItemCount(): Int {
        return Consumidor.size
    }

}
