package com.example.pruebasfirebase

import android.content.ContentValues.TAG
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [totalGastos.newInstance] factory method to
 * create an instance of this fragment.
 */
class totalGastos : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_total_gastos, container, false)

        // Find the button by its ID
        val button = view.findViewById<Button>(R.id.botonEnviar)

        // Set the OnClickListener to handle the button click
        button.setOnClickListener {

            // Get a reference to the Firestore database
            val db = Firebase.firestore

            // Get a reference to the collection where you want to add the value
            val collectionRef = db.collection("Producto")

            // Get the text from the EditText
            val nombre = view.findViewById<EditText>(R.id.nombre).text.toString()
            val precio = view.findViewById<EditText>(R.id.precio).text.toString()
            val amigo = view.findViewById<EditText>(R.id.nombreAmigo).text.toString()

            // Set default values for responsible, paid, and payment
            val defaultResponsible = false
            val defaultPaid = false
            val defaultPayment = 0

            // Create a new document with the text as its data
            val data = hashMapOf(
                "nombre" to nombre,
                "precio" to precio,
                "pagado" to defaultPaid,
                "consumidores" to hashMapOf(
                    amigo to hashMapOf(
                        "responsable" to defaultResponsible,
                        "abono" to defaultPayment,
                        "nombre" to amigo
                    )
                )
            )

            collectionRef.add(data)
                .addOnSuccessListener { documentReference ->
                    Log.d(TAG, "DocumentSnapshot added with ID: ${documentReference.id}")
                    // Clear the EditText
                    view.findViewById<EditText>(R.id.nombre).setText("")
                    view.findViewById<EditText>(R.id.precio).setText("")
                    view.findViewById<EditText>(R.id.nombreAmigo).setText("")
                    // Add your code here to handle the button click
                    Toast.makeText(requireContext(), "Datos Enviados Correctamente", Toast.LENGTH_LONG).show()
                }
                .addOnFailureListener { e ->
                    Log.w(TAG, "Error adding document", e)
                }
        }

        return view
    }




    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment totalGastos.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            totalGastos().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}