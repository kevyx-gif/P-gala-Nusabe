package com.example.pruebasfirebase

data class Producto(val nombre:String, val precio:Double, val consumidores: List<Consumidor>)

data class Consumidor(var nombre: String, var abono:Double)