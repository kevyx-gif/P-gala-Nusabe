package com.example.pruebasfirebase

data class datosFirebase(val nombreUnico:String, val id:Int, val Amigos:Amigo)

data class Amigo(val nombreAmigo:String, val deudaActiva:deuda)

data class deuda(val cantidadDeuda:Double, val monto:Double, val enDeuda:Float, val idProducto:String)

data class Producto(val nombre:String, val precio:Double, val consumidores: List<Consumidor>)

//data class Consumidor(var nombre: String, var responsable:Boolean, var abono: String)
data class Consumidor(var nombre: String, var responsable:Boolean)