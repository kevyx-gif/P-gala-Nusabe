package com.example.pruebasfirebase

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Adaptador(val productos:List<Producto>)
    :RecyclerView.Adapter<Adaptador.ViewHolder>() {

    class ViewHolder(v:View):RecyclerView.ViewHolder(v) {
        var nombre:TextView
        var precio:TextView
        var responsable:TextView
        var amigo1:TextView
        var amigo2:TextView
        var amigo3:TextView

        init {
            nombre = v.findViewById(R.id.textView2)
            precio = v.findViewById(R.id.textView3)
            responsable = v.findViewById(R.id.textView7)
            amigo1 = v.findViewById(R.id.textView4)
            amigo2= v.findViewById(R.id.textView5)
            amigo3= v.findViewById(R.id.textView6)
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Adaptador.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.fila_perfiles,parent,false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: Adaptador.ViewHolder, position: Int) {
        val p = productos[position]
        holder.nombre.text = p.nombre
        holder.precio.text = p.precio.toString()
        val consumidores = p.consumidores
        holder.responsable.text = consumidores.find { it.responsable }?.nombre ?: ""
        holder.amigo1.text = consumidores.getOrNull(0)?.nombre ?: ""
        holder.amigo2.text = consumidores.getOrNull(0)?.nombre ?: ""
        holder.amigo3.text = consumidores.getOrNull(0)?.nombre ?: ""
    }

    override fun getItemCount(): Int {
        return productos.size
    }

}