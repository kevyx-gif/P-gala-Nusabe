package com.example.pruebasfirebase

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pruebasfirebase.Consumidor


class Adaptador(val productos:List<Producto>)
    :RecyclerView.Adapter<Adaptador.ViewHolder>() {

    class ViewHolder(v:View):RecyclerView.ViewHolder(v) {
        var nombre:TextView
        var precio:TextView
        var recyclerViewAmigos: RecyclerView

        init {
            nombre = v.findViewById(R.id.Producto)
            precio = v.findViewById(R.id.Precio)
            recyclerViewAmigos = v.findViewById(R.id.AmigosLista)
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.fila_perfiles,parent,false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val p = productos[position]
        holder.nombre.text = p.nombre
        holder.precio.text = p.precio.toString()
        val consumidores = p.consumidores

        // Obtiene el RecyclerView interno y establece el LayoutManager
        val layoutManager = LinearLayoutManager(holder.recyclerViewAmigos.context, LinearLayoutManager.HORIZONTAL, false)
        holder.recyclerViewAmigos.layoutManager = layoutManager

        // Configura el adaptador interno con el conjunto de datos correspondiente
        val adapterAmigos = AdaptadorAmigos(consumidores)
        holder.recyclerViewAmigos.adapter = adapterAmigos

    }

    override fun getItemCount(): Int {
        return productos.size
    }

}